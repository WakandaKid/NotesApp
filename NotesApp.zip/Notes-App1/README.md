# Notes-App
This is an android note app with extensive features such as colorful notes and the ability to include images and links. It uses SQLite database.

<img src = "demo_screens/Screenshot_20211028-165501.png" height = 500>

<img src = "demo_screens/Screenshot_20211028-165553.png" height = 500>

<img src = "demo_screens/Screenshot_20211028-165548.png" height = 500>
